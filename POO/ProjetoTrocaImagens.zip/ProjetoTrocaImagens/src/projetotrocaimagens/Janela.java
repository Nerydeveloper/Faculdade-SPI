package projetotrocaimagens;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Janela extends JFrame{
    private JLabel label;
    
    public Janela(){
        super("Troca de imagens");
        
        label = new JLabel(new ImageIcon("imagens/mario.jpg"));
        label.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                label.setIcon(new ImageIcon("imagens/luigi.jpg"));
            }
        });
        add(label);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setVisible(true);
    }
    
}
