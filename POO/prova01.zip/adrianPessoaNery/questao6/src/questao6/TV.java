package questao6;

/**
 *
 * @author Nerydeveloper
 */
public class TV {
   String marca;
   int tamanho;
   boolean ligada;
   int canalAtual;
   int volume;


    public boolean isLigada() {
        return ligada;
    }


    public void ligar() {
        this.ligada = true;
    }
     public void desligar() {
        this.ligada = false;
    }

    /**
     * @return the canalAtual
     */
    public int getCanalAtual() {
        return canalAtual;
    }

    /**
     * @param canalAtual the canalAtual to set
     */
    public void alterarCanal(int canalAtual) {
        this.canalAtual = canalAtual;
    }

    /**
     * @return the volume
     */
    public int getVolume() {
        return volume;
    }

    public void ajustarVolume(int volume) {
        this.volume = volume;
    }

    @Override
    public String toString() {
        return "TV{" + "marca=" + marca + ", tamanho=" + tamanho + ", ligada=" + ligada + ", canalAtual=" + canalAtual + ", volume=" + volume + '}';
    }
    
    
    
    
   
   

}
