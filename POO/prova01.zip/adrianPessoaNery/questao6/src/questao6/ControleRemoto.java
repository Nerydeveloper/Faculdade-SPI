package questao6;

/**
 *
 * @author Nerydeveloper
 */
public class ControleRemoto{
    TV tv = new TV();
    
    public void ligarTV(){
        this.tv.ligar();
    } 
    public void desligarTV(){
        this.tv.desligar();
    } 
    public void mudarCanal(int valor){
        this.tv.alterarCanal(valor);
    }
    public void ajustarVolume(int valor){
        this.tv.ajustarVolume(valor);
    }

    @Override
    public String toString() {
        return "ControleRemoto{" + "tv=" + tv + '}';
    }
   
}
