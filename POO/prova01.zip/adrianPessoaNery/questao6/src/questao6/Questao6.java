package questao6;

/**
 *
 * @author Nerydeveloper
 */
public class Questao6 {


    public static void main(String[] args) {
       ControleRemoto controle = new ControleRemoto();
       
       controle.ligarTV();
       controle.ajustarVolume(10);
       controle.mudarCanal(2);
       controle.tv.marca = "LG";
       controle.tv.tamanho = 30;
       
       System.out.println("Estado: " + controle);
        
    }
    
}
