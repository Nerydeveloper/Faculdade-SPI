package questao5;

/**
 *
 * @author Nerydeveloper
 */
public class MonitorEnergia {
    
    static double tarifaAtual = 0.2;
    private double consumo;
    private double contador;
     
    public void adicionarConsumo(double tempoHora){
        this.consumo = tempoHora;   
    }
    
    public void resetarContador(){
        this.contador = 0;
    }
    public String exibirConsumoTotal(){
        double consumototal = this.tarifaAtual * this.consumo;
        return "Você consumiu " + consumototal;
    }
}
