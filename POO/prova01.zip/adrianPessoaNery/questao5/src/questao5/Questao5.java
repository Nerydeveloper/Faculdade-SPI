package questao5;

/**
 *
 * @author Aluno
 */
public class Questao5 {

    public static void main(String[] args) {
        
        MonitorEnergia casa1 = new MonitorEnergia();
        
        casa1.adicionarConsumo(1234);
        casa1.resetarContador();
        System.out.println("Casa 01: " + casa1.exibirConsumoTotal());
    }
    
}
